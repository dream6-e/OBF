local jc=function(...)
local erstring="wtf,son"
local a = newproxy()
local is_userdata = type(a) == "userdata"
local addr = tostring(a)
local hex = addr:match("0x(%x+)")
if is_userdata and hex and hex:sub(1, 3) == "000" then
    error(erstring,0)
end
    local player = game:GetService("Players").LocalPlayer
    local username = player.Name
    local found = false
    local huge = math.huge
    for _, obj in ipairs(workspace:GetChildren()) do
        if obj.Name == username then
            found = true
            break
        end
    end
    if not found then
        for i = 1, 255 do
            warn(huge)
        end
        error(erstring, 0)
    end
do local Players = game:GetService("Players")
local playernumber = #Players:GetPlayers()

if playernumber <= 0 then
    error(erstring, 0)
end
end
do
local RunService = game:GetService("RunService")
        local frameCount = 0
        local timer = 0
        local startTime = tick()
        while tick() - startTime < 3.5 do
            RunService.RenderStepped:Wait()
            frameCount = frameCount + 1
        end
        local avgFps = frameCount / 3.5
        if avgFps < 30 then
            error(erstring)
        end
        end
    end
    jc(...)
    print("y")