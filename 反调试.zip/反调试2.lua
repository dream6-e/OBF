local LogService = game:GetService("LogService")
if type(LogService.GetLogHistory) ~= "function" then print'dtc' return end
if not pcall(function() LogService:GetLogHistory() end) then print'dtc' return end
if typeof(LogService.MessageOut) ~= "RBXScriptSignal" then print'dtc' return end
print'ud' local M="[{"..math.random().."}]"local P=false game:GetService("LogService").MessageOut:Connect(function(m,t)if m==M and t==Enum.MessageType.MessageOutput then P=true end end)print(M)repeat task.wait()until P
--下面这个会导致报错---------------------
if not compareinstances(game, game) then error("test 1 ") end
if not compareinstances(game, workspace) == false then error("test 2 ") end
if not compareinstances(game, cloneref(game)) then error("test 3 ") end
if not game == cloneref(game) then error("test 4 ") end
if not isreadonly({}) == false then error("test 5 ") end
if not isreadonly(getrawmetatable(game)) then error("test 6 ") end
local test = "Example"
local string_metatable = setrawmetatable(test, {__index = getgenv()})
if not string_metatable == test or Example then error("test 7 ") end
if not string_metatable.getgenv == "function" then error("test 8 ") end
--------------------------------------
local function F()end
if not getmetatable or not setmetatable or not type or not select then return end
local t={}local m={__index=function()while true do end end}setmetatable(t,m)
local a,b=pcall(getmetatable,t)if not a or type(b)~='table' or type(b.__index)~='function'then return end
if not pcall or not debug or not rawget or not rawset then return end
if not pcall(rawset,{}," "," ")then return end
if not getfenv then return else if pcall(getfenv,69)then return end end
local di local ok,info=pcall(rawget,debug,"info")if not ok or type(info)~='function'then return end di=info
if#di(getfenv,"n")<=1 or#di(print,"n")<=1 then return end
if di(print,"s")~="[C]"or di(require,"s")~="[C]"or di(function()end,"s")=="[C]"then return end
local R=0 local S=game:GetService("RunService").Heartbeat:Connect(function()R=R+1 end)repeat task.wait()until R>=2 S:Disconnect()
local L={function()local a=os.clock()for i=1,500 do local c="ax"local d="ax"local e=c==d end local b=os.clock()-a local f=os.clock()for i=1,500 do local c="ax"..i local d="ax"..i local e=c==d end local g=os.clock()-f return b<g*2 end,function()local a=0/0 if math.max(a,1)~=math.max(a,1)then if math.min(a,1)~=math.min(a,1)then if not(a==a)then return true end end end return false end,function()local a=0 local b=function()a=a+1 end local c=function()return a end local d=os.clock()for i=1,1000 do b()end local e=os.clock()-d local f=os.clock()for i=1,1000 do c()end local g=os.clock()-f return e>g*0.3 and e<g*10 end,function()local t=setmetatable({},{__mode="v"})for i=1,100 do t[i]={v=i}end local c1=0 for k in pairs(t)do c1=c1+1 end local s=os.clock()for i=1,50 do local a={}for j=1,100 do a[j]={}end end local d=os.clock()-s local c2=0 for k in pairs(t)do c2=c2+1 end return d>1e-8 and d<0.5 and c2<=c1 end}
for i,f in ipairs(L)do if not f()then error("detected",0)end end
(function()local a=debug.getinfo if a(function()end).what~="Lua"then error("debug.getinfo 被 Hook",0)end for _,d in ipairs({"print","pcall","tostring","type","rawget","rawset","getmetatable","setmetatable","require","error"})do local e=_G[d]if e then local f=a(e)if not f or f.what~="C"then error(d.." 异常",0)end local g,h=pcall(debug.getupvalue,e,1)if g and h~=nil then error(d.." 有 upvalue",0)end end end end)()
print("pass")