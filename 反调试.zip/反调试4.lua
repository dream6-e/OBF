local z,x,c,v,f=typeof,raknet,error,print,0x0;local y="table"
if z(x) ~= y then c('1%@',f) end