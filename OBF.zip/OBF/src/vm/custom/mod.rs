//! Executable VM for AST-produced OBF v2 bytecode. Public `.obf` files keep
//! the canonical opcode-plus-varint ISA2 format, but generated scripts lower
//! that program into a private seed-specific ISA13 image: straight-line words
//! become recipe superoperators, use sites carry operands plus random graph
//! labels, three-stage successor tokens, and five-stage recipe tokens (not
//! plaintext successors/opcodes/recipe ids). Reachable neutral bundles split
//! every real entry and sampled CFG edges. Live dictionary descriptors are
//! validation-equivalent camouflage; actual semantics are split into random-id
//! 1..2-primitive fragments and globally shuffled. ISA12-C permits a 2-op
//! fragment only when token analysis can turn it into a real carried-value
//! dataflow pair: the first result is evaluated once and every safe read in the
//! second primitive goes through a frame-family forwarding closure. Unsupported
//! or control pairs remain single fragments rather than concatenated handlers.
//! Each prototype code image is additionally split into a masked two-node
//! id/owner/next chain; every node is
//! shuffled through one cross-prototype pool and fully validated before user
//! execution. Records/sibling prototypes are shuffled, an unreachable synthetic
//! subtree changes topology, and persistent code records retain only tokens.
//! The semantic image is then losslessly compressed by bounded LZW, protected
//! by an inner ChaCha8 domain, sealed in strict transport frame v2, and
//! protected again by a disjoint outer ChaCha8 domain. Word-XOR/rotate,
//! quarter-round, block, stream/KDF and anti-hook code are independent shuffled
//! fields. ISA13 retains ISA11's live source-witness key schedule and
//! fail-closed runtime attestation, the ISA12 per-prototype heterogeneous
//! operand ABI (four physical record layouts, rotation, sparse lane, varied
//! fragment bindings, no actual-opcode marker), the ISA12-B register ABI
//! (four 257-key bank shapes, no complete permutation table) and the ISA12-C
//! carried-value fusion plus six-state entry graph. ISA13 additionally
//! de-documents parser field order: record headers use a per-prototype
//! factorial slot permutation, segment tokens a per-segment one, while
//! dictionary, metadata and tuple orders are per-image permutations baked
//! into the generated parser. All inverses and graph dependencies remain
//! client-visible and reversible. Share parity also selects
//! one of two fetch/dispatch state pairs before masking their representation.
//! Primitive semantics still live in the two target opcode subfolders. The
//! seed never changes public `.obf` bytes, but it does change the embedded
//! semantic image as well as transport, layout, local, and private-field
//! randomization.

mod bitops;
mod chacha;
mod cipher;
mod compress;
mod constant_fields;
mod context;
mod emit;
mod emit_decode;
mod emit_prelude;
mod layout;
mod loader;
mod lowering;
mod mba;
mod opaque_bits;
mod opaque_shapes;
mod seed;
mod seed_deform;
mod seed_routines;
mod semantic;
mod spelling;
mod structure;
#[cfg(test)]
mod tests;
mod transport;
mod transport_fragments;

use crate::bytecode::custom::{self, Opcode, Program};
use crate::{Diagnostic, Target};

pub(crate) use bitops::*;
pub(crate) use chacha::*;
pub(crate) use cipher::*;
pub(crate) use compress::*;
pub(crate) use emit::generate;
pub(crate) use emit_decode::*;
pub(crate) use emit_prelude::*;
pub(crate) use lowering::*;
pub(crate) use mba::*;
pub(crate) use seed::*;
pub(crate) use structure::*;
pub(crate) use transport::*;
pub use transport::{
    base86_decode_mixed, base86_image_alphabet, base86_segment_alphabet, decrypt_embedded,
    extract_embedded, transport_witness,
};
pub(crate) use transport_fragments::*;

pub fn compile(source: &str, target: Target) -> Result<Vec<u8>, Diagnostic> {
    custom::encode(&crate::ir::compile(source, target)?)
}

pub fn virtualize(source: &str, target: Target, seed: u64) -> Result<String, Diagnostic> {
    let bytecode = compile(source, target)?;
    emit(&bytecode, target, seed)
}

/// Validate externally supplied custom bytecode before generating a runtime.
pub fn emit(bytecode: &[u8], target: Target, seed: u64) -> Result<String, Diagnostic> {
    let program = custom::decode(bytecode, target)?;
    let raw = generate(bytecode, &program, seed)?;
    finalize(&raw, target, seed)
}

/// The same pipeline without the constant-field lift. Tests that count how a
/// *spelling* is written (guard predicates, dead arms) need the text the field
/// builders emitted, because the lift replaces those literal spellings with
/// `<wrapper>.<key>` reads whose values are identical.
#[cfg(test)]
pub(crate) fn emit_unlifted(
    bytecode: &[u8],
    target: Target,
    seed: u64,
) -> Result<String, Diagnostic> {
    let program = custom::decode(bytecode, target)?;
    let raw = generate(bytecode, &program, seed)?;
    // K4: the layout pass runs on both sides of this comparison, so the size the
    // ratchet measures is the constant-field pass's own, not the layout pass's.
    let raw = layout::restructure(&raw, target, seed)?;
    let source = super::fields::shorten(&raw, target, seed)?;
    let source = crate::minify::finalize_vm(&source, target, seed)?;
    // L1: the string-respell stage runs on both sides too (same bind), so the
    // size ratchet still isolates exactly the constant-field pass's own cost.
    spelling::respell_script_strings(&source, seed, target)
}

// All source (including static host method adapters) is complete before
// shortening private fields and then applying the existing final local pass.
fn finalize(source: &str, target: Target, seed: u64) -> Result<String, Diagnostic> {
    // K4：先重排生成脚本里的函数级布局（内联/外提/声明顺序），再走下面那三段。
    // 它只改写文本，语义镜像与容器一字不动，所以 `obf compile` 的 `.obf` 与 image
    // pin 必须逐字节不变；行为等价性由 `tests/layout.rs` 的真机差分把门。
    let source = layout::restructure(source, target, seed)?;
    // Goal 6 (part 3): the two enumerable little state chains of the seed-mode
    // validator -- the 12-arm seed-ISA opcode dispatch and the reference-kind
    // arms -- are re-spelled with opaque literals here, i.e. after every pass
    // that anchors on their canonical decimal spelling and before the constant
    // lift / rename / minify stages. Production only, so the gates that read
    // `finalize_unlaid` still see the canonical text.
    let (source, arms) = seed_deform::opaque_state_arms(&source, target, seed);
    debug_assert!(
        arms == 0 || arms >= 12,
        "opaque_state_arms: chain vanished ({arms} arms)"
    );
    let source = finalize_unlaid(&source, target, seed)?;
    // L1 (2026-09-19, analysis/luraph/混淆技术全解.md §A): seeded escape-spelling
    // of the surviving plaintext string literals ("userdata"/"table"/"function"
    // anchors inside NAMECALL adapters and pooled name tables). Must run AFTER
    // finalize_vm, whose canonical string emission would otherwise decode the
    // escapes again. Value-identical by construction (<0x20-0x7E bodies only,
    // full re-lex contract), so bindings, probe shapes and the wire image are
    // untouched; production only.
    spelling::respell_script_strings(&source, seed, target)
}

/// The three stages that follow the layout pass, i.e. everything after the one
/// text-level rewrite. Split out because the gates that compare bindings one for
/// one have to see the text these stages actually received, and the layout pass
/// *adds* bindings (a hoisted helper plus its parameters), so a comparison
/// anchored on the pre-layout text misaligns by construction. The production
/// pipeline has exactly one caller: `finalize` above, which is this plus layout.
pub(crate) fn finalize_unlaid(
    source: &str,
    target: Target,
    seed: u64,
) -> Result<String, Diagnostic> {
    // 先把重复的轮常数搬进包装表的字段（脚本格式一字不动），再缩短私有字段、过命名通道。
    let source = constant_fields::lift(source, target)?;
    let source = super::fields::shorten(&source, target, seed)?;
    crate::minify::finalize_vm(&source, target, seed)
}
