print(12)
